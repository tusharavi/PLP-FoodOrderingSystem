export interface UserModel{
    userId:any;
    username:any;
    password:any;
    telephone:any;
    email:any;
    roles:any;
}