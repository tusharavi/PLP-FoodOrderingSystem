export interface FoodModel{
    foodId:any;
    foodName:any;
    foodPrice:any;
    vegetarian:boolean;
}