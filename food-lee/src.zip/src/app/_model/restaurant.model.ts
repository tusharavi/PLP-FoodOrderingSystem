export interface RestaurantModel{
    restaurantId:any;
    restaurantName:any;
}