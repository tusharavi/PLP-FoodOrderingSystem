export interface FoodOrderModel{
    foodOrderId:any;
}